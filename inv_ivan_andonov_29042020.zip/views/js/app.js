$(document).ready(function() {  

    let state = {
        loggedAdmin: 0,
        loggedVisitor: 0,
        invalidLogin: 0,
        mainTplInitUrl: '',
        categories: [],
        currentCatId: 0,
        currentLinkId: '',
        currentFileId: 0,
        files: []
    };

    let mainSelectors = {
        nav: $('#nav-with-login'),
        navIcon: $('#navIcon'),
        loginModalSel: $('#login-modal-holder'),
        infoModal: $('#info-modal-holder'),
        insContentModal: $('#ins-content-modal-holder'),
        editContentModalHolder: $('#edit-content-modal-holder'),
        manageCategoryModalHolder: $('#manage-category-modal-holder'),
        saveContBtn: $('#saveContBtn'),
        mainTpl: document.getElementById("main-tpl"),
        insCatOptions: document.getElementById("ins-categories"),
        editCatOptions: document.getElementById("edit-categories"),
        comp_front_end: $('#front-end'),
        comp_js: $('#js')
    };

    let commonRenderers = {

        renderNavbar: function(selector) {
            let out = '';
            out += `
                <div class="mytopnav">
                        
                    <a href="javascript:void(0);" 
                        class="active" 
                        style="display:block;height:100%;"
                        >
                        Oncle Vanyo's F1
                    </a>

                    <div id="myLinks">
                            <a href="/"> Home </a>
                        <a href="#ins-content" 
                            id="ins-content" 
                            data-toggle="modal" 
                            data-target="#insertContentModal"
                            >
                            Insert Content
                        </a>
                        <a href="#manage-category" 
                            id="manage-category" 
                            data-toggle="modal" 
                            data-target="#manageCategoryModal"
                            >
                            Manage Category
                        </a>
                        <a href="#" 
                            class="btn btn-info btn-lg" 
                            data-toggle="modal" 
                            data-target="#loginModal" 
                            id="login-link"
                            style="margin-top:8px;margin-bottom:8px;font-size:18px;"
                            >
                        </a>

                        <div id="content-in-nav" style="height:160px;overflow-y:auto;">

                            <div id="links-for-admin">                                 
                            </div>
                            
                            <div id="links-for-visitor"> 
                                <a href="#" class="inner-link" id="projects_visitor" 
                                    style="padding: 6px 16px 6px 16px;">
                                    Projects
                                </a>
                            </div>

                        </div>

                    </div>

                    <a href="javascript:void(0);" 
                        class="icon"  
                        id="navIcon">  
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a> 

                </div>

                <div class="modal fade" id="loginModal" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">
                                    &times;
                                </button>
                                <h4 class="modal-title"> Login User form </h4>
                            </div>
                            <div class="modal-body">

                                <div class="container" id="login-form">
                                    <form id="loginForm">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="glyphicon glyphicon-user"></i>
                                            </span>
                                                <input id="email" 
                                                    type="text" 
                                                    class="form-control" 
                                                    name="email" 
                                                    placeholder="Email"
                                                    required> 
                                        </div>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="glyphicon glyphicon-lock"></i>
                                            </span>
                                            <input id="password" 
                                                type="password" 
                                                class="form-control" 
                                                name="password" 
                                                placeholder="Password" 
                                                required>
                                        </div>
                                        
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-default"> 
                                                Login 
                                            </button>    
                                            <button type="button" 
                                                class="btn btn-default" 
                                                data-dismiss="modal"
                                                id="closeBtn"> 
                                                Close 
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="login-modal-holder"> </div>

                <script>
                    
                    let selectorNavIcon = $('#navIcon');
                    toggleNavIcon(selectorNavIcon);
                    
                    function toggleNavIcon(selectorNavIcon) {

                        selectorNavIcon.click(function() {
                            var navBtn = document.getElementById("myLinks");
                            if (navBtn.style.display === "block") {
                                navBtn.style.display = "none";
                            } else {
                                navBtn.style.display = "block";
                            }
                        });
                    }

                </script>

                <style>
                    .mytopnav {
                        overflow: hidden;
                        background-color: #333;
                        position: relative;
                    }

                    .mytopnav #myLinks {
                        display: none;
                    }

                    .mytopnav a {
                        color: white;
                        padding: 14px 16px;
                        text-decoration: none;
                        font-size: 17px;
                        display: block;
                    }

                    a.icon {
                        width: 40px;
                        height:42px;
                        background: black;
                        display: block;
                        position: absolute;
                        right: 0;
                        top: 0;
                        padding: 4px;
                        margin-right:8px;
                    }

                    .inner-link {
                        padding: 6px 16px 6px 16px;
                    }

                    .inner-link:hover {
                        background-color: #ddd;
                        color: black;
                    }

                    .action-link {
                        display: block;
                        border-radius: 4px;
                        margin-top: 8px;
                    }

                    .action-link:visited {
                        text-decoration: none!important;
                        color: black !important;
                    }

                    .action-link:hover {
                        text-decoration: none!important;
                        background-color: black!important;
                        color: white !important;
                    }

                    .mytopnav a.active {
                        background-color: black;
                        color: white;
                        height: 42px;
                    }

                    .mytopnav a.active {
                        background-color: black;
                        color: white;
                        height: 42px;
                    }

                    .mytopnav a.active:after {
                        content: "";
                    }

                    .icon-bar {
                        display:block;
                        width: 35px;
                        height: 4px;
                        background-color: white;
                        margin: 6px 0;
                    }


                    #login-form {
                        max-width: 100%;
                    } 

                    #login-link {
                        background: none;
                        font-size: 14px;
                    }

                    #logout {
                        background: none;
                        font-size: 14px;
                    }

                    #ins-content {
                        display: none;
                    }
                    #manage-category {
                        display: none;
                    }
                </style>
            `;

            selector.html(out);
        },

        renderInsContentModal: function(selector) {
            let out = `
                <style>  
                    #insContentForm {
                        width: 534px;
                    }

                    @media screen and (max-width: 600px) {
                        #insContentForm {
                            width: 100% !important;
                            overflow:auto;
                        }
                    } 
 
                    #ins-categories {
                        position: relative;
                        z-index: 2;
                        float: left;
                        width: 100%!important;
                        margin-bottom:0px;
                        height: 34px;
                        border-radius: 4px;
                    }
                </style>
                <div class="modal fade" id="insertContentModal" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">
                                    &times;
                                </button>
                                <h4 class="modal-title"> Insert File Content Form </h4>
                            </div>
                            <div class="modal-body">

                                <div class="container" id="ins-content-form">
                                    <form id="insContentForm">

                                        <div class="input-group" style="width:100%;">
                                            <select class="custom-select" id="ins-categories">
                                            </select>
                                        </div>

                                        <p> File Name: </p>
                                        <div class="input-group" style="width:100%;">
                                            <span class="input-group-addon">
                                                <i class="glyphicon glyphicon-tags"></i>
                                            </span>                                        
                                            <input id="insFileName" 
                                                    type="text" 
                                                    class="form-control" 
                                                    name="insFileName" 
                                                    placeholder="File name"
                                                    required
                                                    >
                                        </div>

                                        <p> File Content: </p>
                                        <div class="input-group" style="width:100%;">
                                            <textarea name="insFileContent" 
                                                id="insFileContent" 
                                                style="width:100%;height:240px;"
                                                > Enter the file content here ..
                                            </textarea>
                                        </div>
                                                                            
                                        <div class="input-group" style="width:100%;">
                                            <br>
                                            <!--<button type="submit" class="btn btn-default">-->
                                            <button type="button" id="saveContBtn">
                                                Save  
                                            </button> 
                                            <!--
                                            &nbsp;
                                            <button type="reset" class="btn btn-default"> 
                                                Reset 
                                            </button>
                                            -->
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>               
            `;

            $(selector).html(out);
        },

        renderEditContentModal: function(selector) {
            let out = `
                <style>  
                    #editContentForm {
                        width: 534px;
                    }

                    @media screen and (max-width: 600px) {
                        #editContentForm {
                            width: 100% !important;
                            overflow:auto;
                        }
                    } 
 
                    #edit-categories {
                        position: relative;
                        z-index: 2;
                        float: left;
                        width: 100%!important;
                        margin-bottom:0px;
                        height: 34px;
                        border-radius: 4px;
                    }
                </style>
                <div class="modal fade" id="editContentModal" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">
                                    &times;
                                </button>
                                <h4 class="modal-title"> Edit File Content Form </h4>
                            </div>
                            <div class="modal-body">

                                <div class="container" id="edit-content-form">
                                    <form id="editContentForm">

                                        <p> File Id:</p>
                                        <div class="input-group" style="width:100%;">
                                            <span class="input-group-addon">
                                                <i class="glyphicon glyphicon-saved"></i>
                                            </span>
                                            <input id="editFileId"
                                                    type="text"
                                                    class="form-control" 
                                                    name="editFileId" 
                                                    value=""
                                                    disabled
                                                    >
                                        </div>

                                        <div class="input-group" style="width:100%;">
                                            <select class="custom-select" id="edit-categories">
                                            </select>
                                        </div>                                   

                                        <p> File Name: </p>
                                        <div class="input-group" style="width:100%;">
                                            <span class="input-group-addon">
                                                <i class="glyphicon glyphicon-tags"></i>
                                            </span>                                        
                                            <input id="editFileName" 
                                                    type="text" 
                                                    class="form-control" 
                                                    name="editFileName" 
                                                    placeholder="File name"
                                                    required
                                                    >
                                        </div>

                                        <p> File Content: </p>
                                        <div class="input-group" style="width:100%;">
                                            <textarea name="editFileContent" 
                                                id="editFileContent" 
                                                style="width:100%;height:240px;"
                                                > Enter the file content here ..
                                            </textarea>
                                        </div>
                                                                            
                                        <div class="input-group" style="width:100%;">
                                            <br>
                                            <button type="button" id="editContBtn">
                                                Edit  
                                            </button> 
                                            &nbsp;
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>               
            `;

            $(selector).html(out);
        },

        renderManageCategoryModal: function(selector) { 
            let out = `
                <style>

                    #insCategoryForm {
                        width: 534px;
                    }

                    #editCategoryForm {
                        width: 534px;
                    }

                    #ins-categories {
                        position: relative;
                        z-index: 2;
                        float: left;
                        width: 100%!important;
                        margin-bottom:0px;
                        height: 34px;
                        border-radius: 4px;
                    }

                    #editcatsoptions {
                        position: relative;
                        z-index: 2;
                        float: left;
                        width: 100%!important;
                        margin-bottom:0px;
                        height: 34px;
                        border-radius: 4px;
                    }

                    @media screen and (max-width: 600px) {
                        #insCategoryForm {
                            width: 100% !important;
                            overflow:auto;
                        }
                    } 
                </style>
                <div class="modal fade" id="manageCategoryModal" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">
                                    &times;
                                </button>
                                <h4 class="modal-title"> Manage Category </h4>
                            </div>
                            <div class="modal-body">

                                <h4> Insert Category </h4>
                                <div class="container" id="ins-category-form">
                                    <form id="insCategoryForm">

                                        <p> Category Name: </p>
                                        <div class="input-group" style="width:100%;">
                                            <span class="input-group-addon">
                                                <i class="glyphicon glyphicon-tags"></i>
                                            </span>                                        
                                            <input id="insCategoryName" 
                                                    type="text" 
                                                    class="form-control" 
                                                    name="insCategoryName" 
                                                    placeholder="Category name"
                                                    required
                                                    >
                                        </div>

                                        <p> Link id: </p>
                                        <div class="input-group" style="width:100%;">
                                            <span class="input-group-addon">
                                                <i class="glyphicon glyphicon-tags"></i>
                                            </span>                                        
                                            <input id="insLinkId" 
                                                    type="text" 
                                                    class="form-control" 
                                                    name="insLinkId" 
                                                    placeholder="Link id"
                                                    required
                                                    >
                                        </div>
                                                                            
                                        <div class="input-group" style="width:100%;">
                                            <br>
                                            <button type="button" id="saveCategoryBtn">
                                                Save  
                                            </button> 
                                        </div>
                                    </form>
                                </div> 

                                <h4> Edit Category </h4>
                                <div class="container" id="edit-category-form">
                                    <form id="editCategoryForm">

                                    <div class="input-group" style="width:100%;">
                                        <select class="custom-select" id="editcatsoptions">
                                        </select>
                                    </div>

                                        <p> Category Name: </p>
                                        <div class="input-group" style="width:100%;">
                                            <span class="input-group-addon">
                                                <i class="glyphicon glyphicon-tags"></i>
                                            </span>                                        
                                            <input id="editCategoryName" 
                                                    type="text" 
                                                    class="form-control" 
                                                    name="editCategoryName" 
                                                    placeholder="Category name"
                                                    required
                                                    >
                                        </div>

                                        <p> Link id: </p>
                                        <div class="input-group" style="width:100%;">
                                            <span class="input-group-addon">
                                                <i class="glyphicon glyphicon-tags"></i>
                                            </span>                                        
                                            <input id="editLinkId" 
                                                    type="text" 
                                                    class="form-control" 
                                                    name="editLinkId" 
                                                    placeholder="Link id"
                                                    required
                                                    >
                                        </div>
                                                                            
                                        <div class="input-group" style="width:100%;">
                                            <br>
                                            <button type="button" id="editCategoryBtn">
                                                Edit  
                                            </button> 
                                        </div>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>             
            `;

            $(selector).html(out);
        },

        renderInfoModal: function(selector) {
            let out = `
                <div id="infoModal" class="modal fade" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">
                                    &times;
                                </button>
                                <h4 class="modal-title"> Modal Header </h4>
                            </div>
                            <div class="modal-body">
                                <div id="infoMsg"> </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" 
                                    class="btn btn-default" 
                                    data-dismiss="modal" 
                                    id="closeInfoModalBtn"
                                    >
                                    Close
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            $(selector).html(out);
        }
    };

    commonRenderers.renderNavbar(mainSelectors.nav);
    commonRenderers.renderInfoModal(mainSelectors.infoModal);
    commonRenderers.renderInsContentModal(mainSelectors.insContentModal);
    commonRenderers.renderEditContentModal(mainSelectors.editContentModalHolder);
    commonRenderers.renderManageCategoryModal(mainSelectors.manageCategoryModalHolder);
    
    login();
    initCategories();

    refreshState();

    $('#saveContBtn').click(function() {   

        let selectedCatIdx = document.getElementById("ins-categories").selectedIndex;
        let cat_id = document.getElementById("ins-categories").options[selectedCatIdx].value;

        let file_name = $('#insFileName').val();
        let file_content = $('#insFileContent').val();

        let input = { 
            selectedCatIdx: selectedCatIdx,
            cat_id: cat_id,
            file_name: file_name,
            file_content: file_content
        };
        
        if (isValidContentInput('insert_content', input)) {
            
            action('./index.php?insert_content', input);
            state.currentCatId = input.cat_id;
            initFilesByCatId(state.currentCatId);
            initFilesGrid();
            clearInput();
            $('#insertContentModal').modal('toggle');
            let msgInsContent = '<h2 style="color:green;"> Your record is saved! </h2>';
            $('#infoMsg').html(msgInsContent);
            $('#infoModal').modal('toggle');
            urlAction(state.mainTplInitUrl, state.currentLinkId);
        } else {
            clearInput();
        }
    });

    $('#editContBtn').click(function() {

            let selectedCatIdx = document.getElementById("edit-categories").selectedIndex;
            let cat_id = document.getElementById("edit-categories").options[selectedCatIdx].value;
            
            let file_id = $('#editFileId').val();
            let file_name = $('#editFileName').val();
            let file_content = $('#editFileContent').val();
    
            let input = { 
                file_id: file_id,
                selectedCatIdx: selectedCatIdx,
                cat_id: cat_id,
                file_name: file_name,
                file_content: file_content
            };
    
            if (isValidContentInput('update_content', input)) {
    
                action('./index.php?update_content', input);
                state.currentCatId = input.cat_id;
                initFilesByCatId(state.currentCatId);
                initFilesGrid();
                clearInput();
                $('#editContentModal').modal('toggle');
                let msgEditContent = '<h2 style="color:green;"> Your record is edited! </h2>';
                $('#infoMsg').html(msgEditContent);
                $('#infoModal').modal('toggle');
                urlAction(state.mainTplInitUrl, state.currentLinkId);

            } else {
                 clearInput();
            }
    });

    $('#saveCategoryBtn').click(function() {

        let ins_cat_name = $('#insCategoryName').val();
        let ins_link_id = $('#insLinkId').val();
        
        let input = {
            cat_name: ins_cat_name,
            link_id: ins_link_id
        };

        if (isValidCategoryInput('insert_category', input)) {

            action('./index.php?insert_category', input);
            initCategories();
            clearInput();

            $('#manageCategoryModal').modal('toggle');
            let msgInsCategory = '<h2 style="color:green;"> Your record is saved! </h2>';
            $('#infoMsg').html(msgInsCategory);
            $('#infoModal').modal('toggle');
            
        } else {
            clearInput();
        }
    });

    function initEditableCategories(){

        let promise =  new Promise(function(resolve, reject) {

            let url = './index.php?categories'; 

            let req = new XMLHttpRequest();
            req.open('GET', url, true);						
            req.responseType = 'json';

            req.onload = function() {
                resolve(req.response);
            };

            req.onerror = function() {
                reject(req.statusText);
            };

            req.send();
        });

        promise.then(function(response) {

            let outOptions = '<option selected> -- SELECT CATEGORY -- </option>';

            for (let i = 0; i < response.length; i++) {
                outOptions += '<option value=';
                outOptions += response[i].cat_id;
                outOptions += '>';
                outOptions += response[i].cat_name;
                outOptions += '</option>';
            }

            document.getElementById("editcatsoptions").innerHTML=outOptions; 

        });

    }

    $('#manage-category').click(function() {
        initEditableCategories();
    });

    $('#editCategoryBtn').click(function() {

        let selectedCatIdx = document.getElementById('editcatsoptions').selectedIndex
        let cat_id = document.getElementById("editcatsoptions").options[selectedCatIdx].value;
        let cat_name = document.getElementById("editcatsoptions")[selectedCatIdx].innerText;

        let editCategoryName = $('#editCategoryName').val();
        let editLinkId = $('#editLinkId').val();

        let input = {
            cat_selected_idx: selectedCatIdx,
            cat_id: cat_id,
            cat_name: editCategoryName,
            link_id: editLinkId
        };

        if (isValidCategoryInput('update_category', input)) {
            
            action('./index.php?update_category', input);
            initCategories();
            clearInput();
            $('#manageCategoryModal').modal('toggle');
            let msgEditCategory = '<h2 style="color:green;"> Your record is edited! </h2>';
            $('#infoMsg').html(msgEditCategory);
            $('#infoModal').modal('toggle');
        } else {
            clearInput();
        }
    });
        
    function clearInput() {
        $('#insFileName').val(null);
        $('#insFileContent').val(null);
        $('#insCategoryName').val(null);
        $('#insLinkId').val(null);
        $('#editCategoryName').val(null);
        $('#editLinkId').val(null);
        document.getElementById('editcatsoptions').selectedIndex = 0;
        document.getElementById("ins-categories").selectedIndex = 0;
    }

    function action(url, input) {

        let data = JSON.stringify(input);

        let promise = new Promise(function(resolve, reject) {

            let req = new XMLHttpRequest();					
            req.responseType = 'json';
            req.open("POST", url, true);
            req.onload = function() { 
                resolve(req.response)
            }; 
            req.onerror = function() { 
                reject(req.statusText);
            }; 
            req.send(data);
        });

        return promise;
    }  

    function isValidCategoryInput(action, input) {

        var handleModalOnAction = function(action) {
            
            if (action === 'insert_category') {
                //'./index.php?insert_category'
                $('#manageCategoryModal').modal('toggle');
                
            }

            if (action === 'update_category') {
                //'./index.php?update_category'
                $('#manageCategoryModal').modal('toggle');
            }
        }

        var escapeHtml = function(text) {
            return text
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        };

        for (let x in input) {
            escapeHtml(input.cat_name).trim();
            escapeHtml(input.link_id).trim();
        }

        if (input.cat_name.length > 150) {
            handleModalOnAction(action);
            let errMsgCatName = 'The Category Name should be shorter than 150 characters !';
            $('#infoMsg').html('<h3 style="color:red;">' + errMsgCatName + '</h3>');
            $('#infoModal').modal('toggle');
            return false;
        }
        
        if (action === 'update_category' && input.cat_selected_idx < 1) {
            
            let errMsgCategory = 'You have to select a category !';
            handleModalOnAction(action);           
            $('#infoMsg').html('<h3 style="color:red;">' + errMsgCategory + '</h3>');
            $('#infoModal').modal('toggle');
            return false;
        }

        return true;
    }

    function isValidContentInput(action, input) {

        var handleModalOnAction = function(action) {
            
            if (action === 'insert_content') {
                //mainSelectors.insContentModal.modal('toggle');
                $('#insertContentModal').modal('toggle');
            }

            if (action === 'update_content') {
                $('#editContentModal').modal('toggle');
            }
        }

        var escapeHtml = function(text) {
            return text
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        };

        for (let x in input) {
            escapeHtml(input.cat_id).trim();
            escapeHtml(input.file_name).trim();
            escapeHtml(input.file_content).trim();
        }

        if (input.selectedCatIdx === 0) {
            let errMsgCategory = 'You have to select a category !';
            handleModalOnAction(action);           
            $('#infoMsg').html('<h3 style="color:red;">' + errMsgCategory + '</h3>');
            $('#infoModal').modal('toggle');
            return false;
        }

        if (input.file_name.length > 500) {
            handleModalOnAction(action);
            let errMsgFileName = 'The Filename should be shorter than 500 characters !';
            $('#infoMsg').html('<h3 style="color:red;">' + errMsgFileName + '</h3>');
            $('#infoModal').modal('toggle');
            return false;
        }

        return true;
    }
    
    function login() {
                
        $('#login-link').html('<span class="glyphicon glyphicon-log-in"></span> Login');
        $('#content-in-nav').hide();

        let loginForm = $("#loginForm");
        loginForm.on('submit', function(event) {
            event.preventDefault();
            sendCredentials();
            $("#loginModal").hide();
        });

        function sendCredentials() {    
            
            let email = $("#email").val();
            let password = $("#password").val();

            let input = {
                email: email,
                pwd: password
            };

            let isValidInput = function(input) {
                
                let procedureArr = [];

                var escapeHtml = function(text) {
                    return text
                        .replace(/&/g, "&amp;")
                        .replace(/</g, "&lt;")
                        .replace(/>/g, "&gt;")
                        .replace(/"/g, "&quot;")
                        .replace(/'/g, "&#039;");
                };

                for (let x in input) {
                    escapeHtml(input.email).trim();
                    escapeHtml(input.pwd).trim();
                }
                
                let emailRegEx = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                if (!emailRegEx.test(String(input.email).toLowerCase())) {    
                    procedureArr.push('Invalid email!');
                }

                if (procedureArr.length > 0) {
                
                    window.alert('Invalid username and/or password!');
                    return false;

                } else {
                    return true;
                }
            };

            if (isValidInput) {

                let data = JSON.stringify(input);
                let url = './index.php?login';
                
                let promise = new Promise(function(resolve, reject) { 
                    let req = new XMLHttpRequest();					
                    req.responseType = 'json';
                    req.open("POST", url, true);
                    req.onload = function() { 
                        resolve(req.response);
                    }; 
                    req.onerror = function() { 
                        reject(req.statusText);
                    }; 
                    req.send(data);
                });

                promise.then(function(response) {

                    if (response.token === 'OUT!') {
                        state.invalidLogin = 1;
                        state.loggedAdmin = 0;
                        state.loggedVisitor = 0;
                    }

                    if (response.token === 'admin!123' 
                        || response.token === 'ivan!123') {
                        state.loggedAdmin = 1;
                        state.loggedVisitor = 0;
                    }

                    if (response.token === 'visitor!123') {
                        state.loggedAdmin = 0;
                        state.loggedVisitor = 1;
                    } 

                });

                promise.then(function() {

                    $('#loginModal').modal('toggle'); 
                    let loginLink = $('#login-link');

                    if(state.invalidLogin === 0) {
                        loginLink
                            .html('<span class="glyphicon glyphicon-log-out"></span> Log out')
                            .click(function() {
                            location.reload(true);
                        });
                    }

                    refreshState();
                    router();
                });

                return promise;
            }

        } 

    } 

    function refreshState() {

        if (state.loggedAdmin === 1) {
            document.getElementById("ins-content").style.display="block";
            document.getElementById("manage-category").style.display="block";
            $('#content-in-nav').show();
            $('#links-for-admin').show();
            $('#links-for-visitor').hide();
        }
    
        if (state.loggedVisitor === 1) {
            document.getElementById("ins-content").style.display="none";
            document.getElementById("manage-category").style.display="none";
            $('#ins-content').hide();
            $('#manage-category').hide();
            $('#content-in-nav').show();
            $('#links-for-admin').hide();
            $('#links-for-visitor').show();
        }
    
        if (state.invalidLogin === 1) {
            location.reload();
        }  
    }

    function loadTemplateAndScript(templateUrl, selectorOutput, scriptUrl = '') {

        let getTemplateScript = function (url, callback) {

            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = url;
            // most browsers
            script.onload = callback;
            // IE 6 & 7
            script.onreadystatechange = function() {
                if (this.readyState == 'complete') {
                    callback();
                }
            }
            document.getElementsByTagName('head')[0].appendChild(script);
        }
        
        let promise = new Promise(function(resolve, reject){
                    
            const req = new XMLHttpRequest();
            req.responseType = 'text'; // 'document'
            req.open('POST', templateUrl, true);

            req.onload = function() {
                resolve(req.response);
            };

            req.onerror = function() {
                reject(req.statusText);
            };
            req.send();
        });

        promise.then(function(response) {

            let out = '';
            out += response;
            if (response !== undefined && response !== null) {
                selectorOutput.innerHTML = out;
            }
        });

        promise.then(function(){
            getTemplateScript(scriptUrl);
        });
        
        return promise;
    }

    function initFilesByCatId(cat_id) {

        let input = {cat_id: cat_id};
        let data = JSON.stringify(input);
        
        let promise =  new Promise(function(resolve, reject) {
    
            let url = './index.php?files_by_cat_id';
    
            let req = new XMLHttpRequest();
            req.open('POST', url, true);						
            req.responseType = 'json';
    
            req.onload = function() {
                resolve(req.response);
            };
    
            req.onerror = function() {
                reject(req.statusText);
            };

            req.send(data);

        });

        promise.then(function(response) {

            if(response !== undefined && response !== null) {

                state.files.length = 0; // empty the array

                for (let i = 0; i < response.length; i++) {
                    
                    let obj = {
                        file_id: response[i].file_id,
                        file_name: response[i].file_name,
                        file_content: response[i].file_content,
                        cat_id: response[i].cat_id
                    }

                    state.files.push(obj);
                }

            } 

        });
    
        return promise;
    }

    function initCategories() {

        let promise =  new Promise(function(resolve, reject) {

            let url = './index.php?categories'; 

            let req = new XMLHttpRequest();
            req.open('GET', url, true);						
            req.responseType = 'json';

            req.onload = function() {
                resolve(req.response);
            };

            req.onerror = function() {
                reject(req.statusText);
            };

            req.send();
        });

        promise.then(function(response) {

            let cat_ins_options = document.getElementById("ins-categories");
            let cat_edit_options = document.getElementById("edit-categories");
            let nav_links = document.getElementById("links-for-admin");
            let outOptions = '<option selected> -- SELECT CATEGORY -- </option>';
            let outNavLinks = '';

            for (let i = 0; i < response.length; i++) {
                
                let obj = {
                    cat_id: response[i].cat_id,
                    cat_name: response[i].cat_name,
                    link_href: response[i].link_href,
                    link_class: response[i].link_class,
                    link_id: response[i].link_id,
                    action_route: response[i].action_route
                }

                state.categories.push(obj);

                outOptions += '<option value=';
                outOptions += response[i].cat_id;
                outOptions += '>';
                outOptions += response[i].cat_name;
                outOptions += '</option>';

                outNavLinks += '<a href="' + response[i].link_href + '"';
                outNavLinks += 'class="' + response[i].link_class + '"';
                outNavLinks += 'id="' + response[i].link_id + '">';
                outNavLinks += response[i].cat_name + '</a>';
            }

            cat_ins_options.innerHTML = outOptions;
            cat_edit_options.innerHTML = outOptions;  
            nav_links.innerHTML = outNavLinks;     
        });

        return promise;
    }

    function initFilesGrid() {
        
        let files = state.files;

        $('#main-tpl').html('');

        var escapeHtml = function(text) {
            return text
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        }
        
        let out = '<ul id="result-list">';

        for (let i = 0; i < files.length; i++) {
            
            out += '<div style="border:1px white solid;border-radius:4px;margin-bottom:3px;">';
            out += '<p style="padding-left:10px;margin-top:4px;margin-bottom:2px;">';
            out += '<a href="#" class="editLink" data-toggle="modal" data-target="#editContentModal"> Edit </a>';
            out += '&nbsp;&nbsp; <a href="#" class="deleteLink"> Delete </a>';
            out += '</p>';
            out += '<button class="accordion-collapsible">'; 
            out += 'File name: ' + escapeHtml(files[i].file_name).trim(); 
            out += '</button>';
            out += '<li class="accordion-content">';
            out += '<pre>'; 
            out += escapeHtml(files[i].file_content).trim(); 
            out += '</pre>';
            out += '</li>';
            out += '</div>';
        }

        out += '</ul>';

        out += `
            <style>
                .editLink {
                    color: orangered;
                }
                .deleteLink {
                    color: red;
                }
            </style>
        `;

        $('#main-tpl').html(out);
    }

    function urlAction(url, link_id) {

        let promise =  new Promise(function(resolve, reject) {

            //let url = './index.php?js'; // The only changable part !

            let req = new XMLHttpRequest();
            req.open('POST', url, true);						
            req.responseType = 'json';

            req.onload = function() {
                resolve(req.response);
            };

            req.onerror = function() {
                reject(req.statusText);
            };

            if (link_id !== null && link_id !== undefined) {
                let input = {link_id: link_id};
                let data = JSON.stringify(input);
                req.send(data);
            } else {
                req.send();
            }
        });

        promise.then(function(response) {

            if (response !== undefined && response !== null) {

                state.files.length = 0; // empty the state array
                
                for (let i = 0; i < response.length; i++) {
                    let obj = {
                        file_id: response[i].file_id,
                        file_name: response[i].file_name,
                        file_content: response[i].file_content,
                        cat_id: response[i].cat_id
                    };
                    state.files.push(obj);
                }
               
            }
            
        });

        promise.then(function(response) {

            if (response !== undefined && response !== null) {
                initFilesByCatId(state.currentCatId);
                initFilesGrid();
            } 
        });

        promise.then(function() {
                
            links_open = document.getElementsByClassName("accordion-collapsible");
            
            for (let j = 0; j < links_open.length; j++) {

                links_open[j].onclick = function() {

                    this.classList.toggle("active");
                    var content = this.nextElementSibling;
                    if (content.style.maxHeight) {
                        content.style.maxHeight = null;
                    } else {
                        content.style.maxHeight = content.scrollHeight + "px";
                    }
                }
            }
        });

        promise.then(function(response) {
            
            if (response !== undefined && response !== null) {

                let edit_links = document.getElementsByClassName("editLink");

                for (let i = 0; i < edit_links.length; i++) {
                    edit_links[i].onclick = function() {
                                               
                        state.currentCatId = response[i].cat_id;
                        //state.currentFileId = response[i].file_id;
                        
                        $('#editFileId').val(response[i].file_id);
                        $('#editFileName').val(response[i].file_name);
                        $('#editFileContent').val(response[i].file_content);
                    }
                }

                let delete_links = document.getElementsByClassName("deleteLink");

                for (let j = 0; j < delete_links.length; j++) {
              
                    delete_links[j].onclick = function() {
                       
                        let input = {
                            file_id: response[j].file_id
                        };
                        
                        action('./index.php?delete_content', input);    
                        state.currentCatId = response[j].cat_id; 
                        
                        initFilesByCatId(state.currentCatId);
                        initFilesGrid();
                        urlAction(state.mainTplInitUrl, state.currentLinkId); 
                    }
                }
            }
        });

        return promise;
    }

    function router() {

        if (state.loggedAdmin === 1 || state.loggedVisitor === 1) {
            
            let template_url = './views/components/comp_landing_page/comp_landing_page.html';
            loadTemplateAndScript(template_url, mainSelectors.mainTpl);
        }

        if (state.loggedAdmin === 1 && state.loggedVisitor === 0) {

            let cats = state.categories;           
            
            for(let i = 0; i < cats.length; i++) {

                let selector = document.getElementsByClassName(cats[i].link_class);
                
                let url = './index.php?' + cats[i].action_route; // !!

                let link_id = cats[i].link_id;

                selector[i].onclick = function(){
                    
                    state.mainTplInitUrl = url;
                    state.currentCatId = cats[i].cat_id;
                    state.currentLinkId = link_id;
                    urlAction(state.mainTplInitUrl, state.currentLinkId);
                    initFilesByCatId(state.currentCatId);
                    initFilesGrid();
                };
            }
        }

        if (state.loggedAdmin === 0 && state.loggedVisitor === 1) {
            // TODO
        }
    }


}); // end of $(document).ready(function()